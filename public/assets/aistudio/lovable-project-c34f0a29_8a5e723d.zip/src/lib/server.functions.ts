import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

// Demo accounts: fixed emails only, password is public by design (demo use).
export const DEMO_PASSWORD = "DemoCanteen#2026";
const DEMO = {
  student: { email: "demo.student@smartcanteen.app", name: "Aarav (Demo Student)", meta: { branch: "Computer Science", academic_year: "2" } },
  canteen: { email: "demo.canteen@smartcanteen.app", name: "Meera (Demo Canteen)", meta: {} },
  ngo: { email: "demo.ngo@smartcanteen.app", name: "Annapurna Seva (Demo NGO)", meta: { org_name: "Annapurna Seva Trust (Demo)" } },
  admin: { email: "demo.admin@smartcanteen.app", name: "Dr. Rao (Demo Admin)", meta: {} },
} as const;

export const ensureDemoAccount = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ role: z.enum(["student", "canteen", "ngo", "admin"]) }).parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const d = DEMO[data.role];
    const { data: list } = await supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 200 });
    let user = list?.users.find((u) => u.email === d.email);
    if (!user) {
      const signupRole = data.role === "admin" ? "student" : data.role;
      const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
        email: d.email,
        password: DEMO_PASSWORD,
        email_confirm: true,
        user_metadata: { display_name: d.name, role: signupRole, ...d.meta },
      });
      if (error || !created.user) throw new Error(error?.message ?? "Could not create demo user");
      user = created.user;
    }
    // Trusted server-side provisioning of demo privileges
    if (data.role === "admin") {
      await supabaseAdmin.from("user_roles").upsert({ user_id: user.id, role: "admin" }, { onConflict: "user_id,role" });
    }
    if (data.role === "canteen") await supabaseAdmin.from("profiles").update({ status: "active" }).eq("id", user.id);
    if (data.role === "ngo") await supabaseAdmin.from("ngo_profiles").update({ verification_status: "verified", description: "Demo NGO serving community meals in nearby settlements.", service_area: "Campus + 5 km", contact: "+91 90000 00000" }).eq("user_id", user.id);
    return { email: d.email, password: DEMO_PASSWORD };
  });

async function callAI(messages: { role: string; content: string }[]) {
  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env["LOVABLE_API_KEY"]}`, "Content-Type": "application/json" },
    body: JSON.stringify({ model: "google/gemini-3-flash-preview", messages }),
  });
  if (res.status === 429) throw new Error("AI is busy right now, please try again shortly.");
  if (res.status === 402) throw new Error("AI credits are exhausted for this workspace.");
  if (!res.ok) throw new Error("AI request failed");
  const j = await res.json();
  return (j.choices?.[0]?.message?.content as string) ?? "";
}

export const askCanteenBot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({ messages: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().max(2000) })).max(20) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const sb = context.supabase;
    const [{ data: menu }, { data: seat }, { data: ann }] = await Promise.all([
      sb.from("menu_items").select("name,price,is_available,category"),
      sb.from("canteen_seating_status").select("*").maybeSingle(),
      sb.from("announcements").select("title,body").eq("published", true).order("created_at", { ascending: false }).limit(5),
    ]);
    const ctx = `Menu: ${JSON.stringify(menu)}\nSeating: ${seat?.updated_at ? `${seat.occupied_seats}/${seat.total_seats} occupied (updated ${seat.updated_at})` : "unknown / not updated"}\nAnnouncements: ${JSON.stringify(ann)}`;
    const reply = await callAI([
      { role: "system", content: `You are the helpful assistant of a college Smart Canteen. Answer briefly using ONLY this live data; if something is unknown say so. Never invent prices or availability.\n${ctx}` },
      ...data.messages,
    ]);
    return { reply };
  });

export const forecastDemand = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const sb = context.supabase;
    const since = new Date(Date.now() - 28 * 864e5).toISOString().slice(0, 10);
    const [{ data: batches, error }, { data: menu }, { data: stock }] = await Promise.all([
      sb.from("food_preparation_batches").select("menu_item_id,prep_date,prepared_qty,sold_qty,donated_qty,discarded_qty").gte("prep_date", since),
      sb.from("menu_items").select("id,name"),
      sb.from("ingredient_stock").select("*"),
    ]);
    if (error) throw new Error("Not authorized to view forecasts");
    const tomorrowDow = new Date(Date.now() + 864e5).getDay();
    const rows = (menu ?? []).map((m) => {
      const hist = (batches ?? []).filter((b) => b.menu_item_id === m.id);
      const sameDay = hist.filter((b) => new Date(b.prep_date).getDay() === tomorrowDow);
      const use = sameDay.length >= 2 ? sameDay : hist;
      const avgSold = use.length ? use.reduce((s, b) => s + b.sold_qty, 0) / use.length : null;
      const avgLeft = use.length ? use.reduce((s, b) => s + (b.prepared_qty - b.sold_qty), 0) / use.length : null;
      return {
        dish: m.name,
        samples: use.length,
        basis: sameDay.length >= 2 ? "same weekday" : hist.length ? "all recent days" : "no history",
        expectedDemand: avgSold == null ? null : Math.round(avgSold),
        suggestedPrep: avgSold == null ? null : Math.ceil(avgSold * 1.05),
        avgLeftover: avgLeft == null ? null : Math.round(avgLeft),
        confidence: use.length >= 6 ? "medium" : use.length >= 2 ? "low" : "insufficient data",
      };
    });
    let summary = "";
    if ((batches ?? []).length) {
      try {
        summary = await callAI([
          { role: "system", content: "You are a canteen planning analyst. In 4 short bullet points, explain risks of shortage or surplus and ingredient concerns from the data. Use only given numbers; say they are estimates." },
          { role: "user", content: JSON.stringify({ forecast: rows, stock }) },
        ]);
      } catch (e) {
        summary = e instanceof Error ? e.message : "AI summary unavailable";
      }
    }
    return { rows, summary };
  });
