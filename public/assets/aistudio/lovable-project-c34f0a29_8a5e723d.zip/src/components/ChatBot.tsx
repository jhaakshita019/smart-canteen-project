import { useState } from "react";
import { MessageCircle, Send, X } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { askCanteenBot } from "@/lib/server.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type Msg = { role: "user" | "assistant"; content: string };

export function ChatBot() {
  const ask = useServerFn(askCanteenBot);
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([{ role: "assistant", content: "Hi! Ask me about today's menu, seating or announcements." }]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);

  async function send() {
    if (!text.trim() || busy) return;
    const next = [...msgs, { role: "user" as const, content: text.trim() }];
    setMsgs(next); setText(""); setBusy(true);
    try {
      const r = await ask({ data: { messages: next.slice(-12) } });
      setMsgs([...next, { role: "assistant", content: r.reply }]);
    } catch (e) {
      setMsgs([...next, { role: "assistant", content: e instanceof Error ? e.message : "Something went wrong." }]);
    } finally { setBusy(false); }
  }

  if (!open) return (
    <Button onClick={() => setOpen(true)} className="fixed bottom-5 right-5 h-12 rounded-full shadow-lg" aria-label="Open assistant">
      <MessageCircle className="h-5 w-5" /> Ask AI
    </Button>
  );
  return (
    <div className="fixed bottom-5 right-5 z-50 flex h-[28rem] w-[min(22rem,calc(100vw-2.5rem))] flex-col overflow-hidden rounded-2xl border bg-card shadow-2xl">
      <div className="flex items-center justify-between bg-primary px-4 py-2 text-primary-foreground">
        <span className="font-semibold">Canteen Assistant</span>
        <button onClick={() => setOpen(false)} aria-label="Close"><X className="h-4 w-4" /></button>
      </div>
      <div className="flex-1 space-y-2 overflow-auto p-3 text-sm">
        {msgs.map((m, i) => (
          <div key={i} className={`max-w-[85%] whitespace-pre-wrap rounded-lg px-3 py-2 ${m.role === "user" ? "ml-auto bg-primary text-primary-foreground" : "bg-muted"}`}>{m.content}</div>
        ))}
        {busy && <div className="text-muted-foreground">Thinking…</div>}
      </div>
      <form className="flex gap-2 border-t p-2" onSubmit={(e) => { e.preventDefault(); send(); }}>
        <Input value={text} onChange={(e) => setText(e.target.value)} placeholder="Is paneer available?" />
        <Button size="icon" type="submit" disabled={busy} aria-label="Send"><Send className="h-4 w-4" /></Button>
      </form>
    </div>
  );
}
