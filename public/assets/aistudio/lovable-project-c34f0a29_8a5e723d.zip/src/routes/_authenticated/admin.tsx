import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { AppShell, Section } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Admin Dashboard — Smart Canteen" }, { name: "description", content: "Verify NGOs, moderate posts, schedules." }, { property: "og:title", content: "Admin Dashboard" }, { property: "og:description", content: "Verify NGOs, moderate posts, schedules." }] }),
  component: () => <AppShell role="admin"><Admin /></AppShell>,
});

function Admin() {
  const qc = useQueryClient();
  const d = useQuery({
    queryKey: ["admin"],
    queryFn: async () => {
      const [ngos, posts, staff, sched] = await Promise.all([
        supabase.from("ngo_profiles").select("*").order("created_at"),
        supabase.from("ngo_posts").select("*, ngo_profiles(org_name)").eq("status", "pending"),
        supabase.from("profiles").select("*").eq("status", "pending"),
        supabase.from("lunch_break_schedules").select("*").order("day_of_week"),
      ]);
      return { ngos: ngos.data ?? [], posts: posts.data ?? [], staff: staff.data ?? [], sched: sched.data ?? [] };
    },
  });
  const r = () => qc.invalidateQueries({ queryKey: ["admin"] });
  const [s, setS] = useState({ branch: "Computer Science", year: "1", day: String(new Date().getDay()), start: "12:30", end: "13:15" });
  const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Section title="NGO verification">
        {d.data?.ngos.map((n) => (
          <div key={n.user_id} className="flex items-center justify-between border-b py-2 text-sm">
            <span>{n.org_name} <span className="text-muted-foreground">({n.verification_status})</span></span>
            <span className="flex gap-1">
              <Button size="sm" onClick={async () => { await supabase.from("ngo_profiles").update({ verification_status: "verified" }).eq("user_id", n.user_id); r(); }}>Verify</Button>
              <Button size="sm" variant="outline" onClick={async () => { await supabase.from("ngo_profiles").update({ verification_status: "rejected" }).eq("user_id", n.user_id); r(); }}>Reject</Button>
            </span>
          </div>
        ))}
      </Section>
      <Section title="Posts awaiting moderation">
        {d.data?.posts.length === 0 && <p className="text-sm text-muted-foreground">Nothing pending.</p>}
        {d.data?.posts.map((p) => (
          <div key={p.id} className="border-b py-2 text-sm">
            <div className="font-semibold">{p.title} — {p.ngo_profiles?.org_name}</div><p className="text-muted-foreground">{p.body}</p>
            <div className="mt-1 flex gap-1">
              <Button size="sm" onClick={async () => { await supabase.from("ngo_posts").update({ status: "approved" }).eq("id", p.id); r(); }}>Approve</Button>
              <Button size="sm" variant="outline" onClick={async () => { await supabase.from("ngo_posts").update({ status: "rejected" }).eq("id", p.id); r(); }}>Reject</Button>
            </div>
          </div>
        ))}
      </Section>
      <Section title="Pending canteen staff">
        {d.data?.staff.length === 0 && <p className="text-sm text-muted-foreground">No pending accounts.</p>}
        {d.data?.staff.map((p) => <div key={p.id} className="flex justify-between border-b py-2 text-sm"><span>{p.display_name}</span><Button size="sm" onClick={async () => { await supabase.from("profiles").update({ status: "active" }).eq("id", p.id); r(); }}>Activate</Button></div>)}
      </Section>
      <Section title="Lunch break timetable">
        <form className="grid grid-cols-5 gap-2" onSubmit={async (e) => {
          e.preventDefault();
          const { error } = await supabase.from("lunch_break_schedules").insert({ branch: s.branch, academic_year: Number(s.year), day_of_week: Number(s.day), start_time: s.start, end_time: s.end });
          if (error) toast.error(error.message); else { toast.success("Saved"); r(); }
        }}>
          <select className="col-span-2 rounded-md border bg-background px-2 text-sm" value={s.branch} onChange={(e) => setS({ ...s, branch: e.target.value })}>{["Computer Science", "Electronics", "Mechanical", "Civil", "Electrical", "IT"].map((b) => <option key={b}>{b}</option>)}</select>
          <Input type="number" min={1} max={6} value={s.year} onChange={(e) => setS({ ...s, year: e.target.value })} />
          <select className="rounded-md border bg-background px-2 text-sm" value={s.day} onChange={(e) => setS({ ...s, day: e.target.value })}>{days.map((x, i) => <option key={x} value={i}>{x}</option>)}</select>
          <Button type="submit">Add</Button>
          <Input type="time" className="col-span-2" value={s.start} onChange={(e) => setS({ ...s, start: e.target.value })} />
          <Input type="time" className="col-span-2" value={s.end} onChange={(e) => setS({ ...s, end: e.target.value })} />
        </form>
        <div className="mt-3">{d.data?.sched.map((x) => <div key={x.id} className="border-b py-1 text-sm">{days[x.day_of_week]} · {x.branch} Y{x.academic_year} · {x.start_time.slice(0, 5)}–{x.end_time.slice(0, 5)}</div>)}</div>
      </Section>
    </div>
  );
}
