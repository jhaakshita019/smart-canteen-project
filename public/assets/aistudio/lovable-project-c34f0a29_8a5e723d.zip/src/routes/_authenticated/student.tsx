import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AppShell, Section, Stat } from "@/components/AppShell";
import { useMe } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/student")({
  head: () => ({ meta: [{ title: "Student Dashboard — Smart Canteen" }, { name: "description", content: "Menu, lunch slot and seating." }, { property: "og:title", content: "Student Dashboard" }, { property: "og:description", content: "Menu, lunch slot and seating." }] }),
  component: () => <AppShell role="student"><Student /></AppShell>,
});

function Student() {
  const me = useMe();
  const p = me.data?.profile;
  const d = useQuery({
    queryKey: ["student-dash", p?.branch],
    queryFn: async () => {
      const [menu, seat, ann, sched] = await Promise.all([
        supabase.from("menu_items").select("*").order("name"),
        supabase.from("canteen_seating_status").select("*").maybeSingle(),
        supabase.from("announcements").select("*").eq("published", true).order("created_at", { ascending: false }).limit(5),
        supabase.from("lunch_break_schedules").select("*").eq("branch", p?.branch ?? "").eq("academic_year", p?.academic_year ?? 0),
      ]);
      return { menu: menu.data ?? [], seat: seat.data, ann: ann.data ?? [], sched: sched.data ?? [] };
    },
    enabled: !!p,
    refetchInterval: 30000,
  });
  const today = new Date().getDay();
  const slot = d.data?.sched.find((s) => s.day_of_week === today);
  const seat = d.data?.seat;
  return (
    <div className="space-y-6">
      <div className="grid gap-3 sm:grid-cols-4">
        <Stat label="Branch / Year" value={`${p?.branch ?? "—"} · ${p?.academic_year ?? "—"}`} />
        <Stat label="Today's lunch slot" value={slot ? `${slot.start_time.slice(0, 5)}–${slot.end_time.slice(0, 5)}` : "Not scheduled"} />
        <Stat label="Seats free" value={seat?.updated_at ? seat.total_seats - seat.occupied_seats : "Unknown"} hint={seat?.updated_at ? `Updated ${new Date(seat.updated_at).toLocaleTimeString()}` : "Not updated yet"} />
        <Stat label="Dishes available" value={d.data?.menu.filter((m) => m.is_available).length ?? "—"} />
      </div>
      <Section title="Today's menu">
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {d.data?.menu.length === 0 && <p className="text-sm text-muted-foreground">No menu published yet.</p>}
          {d.data?.menu.map((m) => (
            <div key={m.id} className="flex items-center justify-between rounded-lg border p-3">
              <div><div className="font-semibold">{m.name}</div><div className="text-xs text-muted-foreground">{m.category}</div></div>
              <div className="text-right"><div className="font-bold">₹{m.price}</div><div className={`text-xs ${m.is_available ? "text-success" : "text-destructive"}`}>{m.is_available ? "Available" : "Sold out"}</div></div>
            </div>
          ))}
        </div>
      </Section>
      <Section title="Announcements">
        {d.data?.ann.length === 0 && <p className="text-sm text-muted-foreground">No announcements.</p>}
        {d.data?.ann.map((a) => <div key={a.id} className="border-b py-2"><div className="font-semibold">{a.title}</div><p className="text-sm text-muted-foreground">{a.body}</p></div>)}
      </Section>
    </div>
  );
}
