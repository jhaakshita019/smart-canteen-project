import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { AppShell, Section, Stat } from "@/components/AppShell";
import { useMe } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export const Route = createFileRoute("/_authenticated/ngo")({
  head: () => ({ meta: [{ title: "NGO Dashboard — Smart Canteen" }, { name: "description", content: "Claim surplus food and share impact." }, { property: "og:title", content: "NGO Dashboard" }, { property: "og:description", content: "Claim surplus food and share impact." }] }),
  component: () => <AppShell role="ngo" tone="pink"><Ngo /></AppShell>,
});

function Ngo() {
  const me = useMe();
  const uid = me.data?.user.id;
  const qc = useQueryClient();
  const d = useQuery({
    queryKey: ["ngo", uid],
    enabled: !!uid,
    queryFn: async () => {
      const [prof, list, reqs, posts] = await Promise.all([
        supabase.from("ngo_profiles").select("*").eq("user_id", uid!).maybeSingle(),
        supabase.from("surplus_food_listings").select("*").eq("status", "open").order("created_at", { ascending: false }),
        supabase.from("donation_requests").select("*, surplus_food_listings(description,quantity,unit)").eq("ngo_id", uid!),
        supabase.from("ngo_posts").select("*").eq("ngo_id", uid!).order("created_at", { ascending: false }),
      ]);
      return { prof: prof.data, list: list.data ?? [], reqs: reqs.data ?? [], posts: posts.data ?? [] };
    },
  });
  const [post, setPost] = useState({ title: "", body: "", image_url: "", location: "", beneficiaries: "" });
  const verified = d.data?.prof?.verification_status === "verified";
  const refresh = () => qc.invalidateQueries({ queryKey: ["ngo", uid] });
  return (
    <div className="space-y-6">
      <div className="grid gap-3 sm:grid-cols-3">
        <Stat label="Organisation" value={d.data?.prof?.org_name ?? "—"} />
        <Stat label="Verification" value={<span className={verified ? "text-success" : "text-warning"}>{d.data?.prof?.verification_status ?? "—"}</span>} />
        <Stat label="Requests made" value={d.data?.reqs.length ?? 0} />
      </div>
      <Section title="Available surplus food">
        {!verified && <p className="text-sm text-muted-foreground">Only verified NGOs can see and request surplus food.</p>}
        {verified && d.data?.list.length === 0 && <p className="text-sm text-muted-foreground">No open listings right now.</p>}
        {d.data?.list.map((l) => (
          <div key={l.id} className="flex items-center justify-between border-b py-2">
            <div><div className="font-semibold">{l.quantity} {l.unit} — {l.description}</div><div className="text-xs text-muted-foreground">Available until {new Date(l.available_until).toLocaleString()}</div></div>
            <Button size="sm" className="bg-ngo text-ngo-foreground" disabled={d.data?.reqs.some((r) => r.listing_id === l.id)} onClick={async () => {
              const { error } = await supabase.from("donation_requests").insert({ listing_id: l.id, ngo_id: uid! });
              if (error) toast.error(error.message); else { toast.success("Requested"); refresh(); }
            }}>Request</Button>
          </div>
        ))}
      </Section>
      <Section title="My requests">
        {d.data?.reqs.map((r) => <div key={r.id} className="flex justify-between border-b py-2 text-sm"><span>{r.surplus_food_listings?.quantity} {r.surplus_food_listings?.unit} — {r.surplus_food_listings?.description}</span><span className="font-semibold">{r.status}</span></div>)}
      </Section>
      <Section title="Share an activity post">
        <form className="grid gap-2 sm:grid-cols-2" onSubmit={async (e) => {
          e.preventDefault();
          const { error } = await supabase.from("ngo_posts").insert({ ngo_id: uid!, title: post.title, body: post.body, image_url: post.image_url || null, location: post.location || null, beneficiaries: post.beneficiaries ? Number(post.beneficiaries) : null, activity_date: new Date().toISOString().slice(0, 10) });
          if (error) toast.error(error.message); else { toast.success("Submitted for admin approval"); setPost({ title: "", body: "", image_url: "", location: "", beneficiaries: "" }); refresh(); }
        }}>
          <Input required placeholder="Title" value={post.title} onChange={(e) => setPost({ ...post, title: e.target.value })} />
          <Input placeholder="Image URL (optional, no identifiable children)" value={post.image_url} onChange={(e) => setPost({ ...post, image_url: e.target.value })} />
          <Input placeholder="Location" value={post.location} onChange={(e) => setPost({ ...post, location: e.target.value })} />
          <Input type="number" min={0} placeholder="People reached" value={post.beneficiaries} onChange={(e) => setPost({ ...post, beneficiaries: e.target.value })} />
          <Textarea className="sm:col-span-2" placeholder="What did you do?" value={post.body} onChange={(e) => setPost({ ...post, body: e.target.value })} />
          <Button className="bg-ngo text-ngo-foreground sm:col-span-2" type="submit">Submit post</Button>
        </form>
        <div className="mt-4">{d.data?.posts.map((p) => <div key={p.id} className="flex justify-between border-b py-2 text-sm"><span>{p.title}</span><span>{p.status}</span></div>)}</div>
      </Section>
    </div>
  );
}
