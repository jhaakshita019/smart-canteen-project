import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, BadgeCheck, Leaf, UtensilsCrossed } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { PORTALS, type AppRole } from "@/lib/auth";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Smart Canteen — Less waste, shorter queues, fed communities" },
    { name: "description", content: "AI-powered campus canteen connecting students, canteen staff, admins and verified NGOs to cut food waste." },
    { property: "og:title", content: "Smart Canteen — Campus Food Platform" },
    { property: "og:description", content: "Inventory, demand forecasts, lunch slots and NGO food donations in one place." },
  ] }),
  component: Home,
});

function Home() {
  const posts = useQuery({
    queryKey: ["public-posts"],
    queryFn: async () => (await supabase.from("ngo_posts").select("*, ngo_profiles(org_name, verification_status)").eq("status", "approved").order("created_at", { ascending: false }).limit(6)).data ?? [],
  });
  const impact = useQuery({
    queryKey: ["impact"],
    queryFn: async () => {
      const { data } = await supabase.from("food_preparation_batches").select("prepared_qty,sold_qty,donated_qty,discarded_qty");
      const s = (data ?? []).reduce((a, b) => ({ p: a.p + b.prepared_qty, d: a.d + b.donated_qty, w: a.w + b.discarded_qty }), { p: 0, d: 0, w: 0 });
      return s;
    },
  });
  return (
    <div className="min-h-screen">
      <header className="mx-auto flex max-w-7xl items-center justify-between px-4 py-5">
        <div className="flex items-center gap-2 font-display text-xl font-bold text-primary"><UtensilsCrossed /> Smart Canteen</div>
        <Link to="/$portal/login" params={{ portal: "student" }} className="rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">Sign in</Link>
      </header>
      <section className="mx-auto grid max-w-7xl gap-10 px-4 pb-16 pt-8 lg:grid-cols-[1.3fr_1fr] lg:items-end">
        <div>
          <p className="inline-flex items-center gap-2 rounded-full bg-accent px-3 py-1 text-xs font-semibold text-accent-foreground"><Leaf className="h-3.5 w-3.5" /> Campus food, without the waste</p>
          <h1 className="mt-5 text-5xl font-bold leading-[1.05] text-primary md:text-7xl">Cook what's eaten.<br /><span className="text-ngo">Share what's left.</span></h1>
          <p className="mt-5 max-w-xl text-lg text-muted-foreground">One platform for students, canteen staff, college admins and verified NGOs — with live seating, staggered lunch breaks, an honest stock ledger and AI demand forecasts.</p>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {[["Meals prepared", impact.data?.p], ["Donated", impact.data?.d], ["Discarded", impact.data?.w]].map(([l, v]) => (
            <div key={l as string} className="rounded-2xl border bg-card p-4">
              <div className="font-display text-3xl font-bold text-primary">{v ?? "—"}</div>
              <div className="text-xs text-muted-foreground">{l}</div>
            </div>
          ))}
          <p className="col-span-3 text-xs text-muted-foreground">Totals from recorded canteen batches.</p>
        </div>
      </section>

      <section className="bg-primary py-14 text-primary-foreground">
        <div className="mx-auto max-w-7xl px-4">
          <h2 className="text-3xl font-bold">Choose your portal</h2>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {(Object.keys(PORTALS) as AppRole[]).map((r) => (
              <Link key={r} to="/$portal/login" params={{ portal: r }} className={`group rounded-2xl p-5 transition ${r === "ngo" ? "bg-ngo text-ngo-foreground" : "bg-background/10 hover:bg-background/15"}`}>
                <div className="font-display text-xl font-bold">{PORTALS[r].label}</div>
                <p className="mt-1 text-sm opacity-85">{PORTALS[r].blurb}</p>
                <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold">Login / demo <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" /></span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-14">
        <h2 className="text-3xl font-bold text-ngo">From our NGO partners</h2>
        <p className="text-muted-foreground">Activity posts approved by the college admin.</p>
        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {(posts.data ?? []).length === 0 && <p className="text-sm text-muted-foreground">No approved posts yet.</p>}
          {(posts.data ?? []).map((p) => (
            <article key={p.id} className="overflow-hidden rounded-2xl border bg-card">
              {p.image_url && <img src={p.image_url} alt={p.title} className="h-44 w-full object-cover" loading="lazy" />}
              <div className="p-4">
                <div className="flex items-center gap-1 text-xs font-semibold text-ngo">
                  {p.ngo_profiles?.org_name}
                  {p.ngo_profiles?.verification_status === "verified" ? <BadgeCheck className="h-3.5 w-3.5" /> : <span className="text-muted-foreground">(unverified)</span>}
                </div>
                <h3 className="mt-1 text-lg font-bold">{p.title}</h3>
                <p className="mt-1 line-clamp-3 text-sm text-muted-foreground">{p.body}</p>
                <div className="mt-2 text-xs text-muted-foreground">{[p.location, p.activity_date, p.beneficiaries != null && `${p.beneficiaries} people reached`].filter(Boolean).join(" · ")}</div>
              </div>
            </article>
          ))}
        </div>
      </section>
      <footer className="border-t py-6 text-center text-xs text-muted-foreground">Smart Canteen · Campus food management</footer>
    </div>
  );
}
