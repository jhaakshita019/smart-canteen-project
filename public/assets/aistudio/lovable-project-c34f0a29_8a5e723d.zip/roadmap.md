# Roadmap
- [x] Database schema with roles, inventory ledger, donations, NGO posts, notifications
- [x] Role login pages + dashboards (student, canteen, ngo, admin)
- [x] AI chatbot + demand forecast
- [x] Demo login per role + sample data/workflows
- [x] supabase/schema.sql copy
