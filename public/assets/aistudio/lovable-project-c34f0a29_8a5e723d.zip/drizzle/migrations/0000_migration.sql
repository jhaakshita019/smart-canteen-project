create type public.app_role as enum ('admin','canteen','ngo','student');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  status text not null default 'active' check (status in ('active','pending','suspended')),
  branch text,
  academic_year int check (academic_year between 1 and 6),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  unique (user_id, role)
);
grant select, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;
create or replace function public.is_staff(_uid uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.has_role(_uid,'admin') or (public.has_role(_uid,'canteen') and exists(select 1 from public.profiles where id=_uid and status='active'))
$$;

create policy "own profile read" on public.profiles for select to authenticated using (id = auth.uid() or public.has_role(auth.uid(),'admin'));
create policy "own profile update" on public.profiles for update to authenticated using (id = auth.uid() or public.has_role(auth.uid(),'admin'));
create policy "own roles read" on public.user_roles for select to authenticated using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));

create or replace function public.guard_profile_status() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if new.status is distinct from old.status and not public.has_role(auth.uid(),'admin') then
    new.status := old.status;
  end if;
  new.updated_at := now();
  return new;
end $$;
create trigger trg_guard_profile before update on public.profiles for each row execute function public.guard_profile_status();

create table public.ngo_profiles (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  org_name text not null,
  description text default '',
  contact text default '',
  service_area text default '',
  verification_status text not null default 'pending' check (verification_status in ('pending','verified','rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select on public.ngo_profiles to anon;
grant select, insert, update on public.ngo_profiles to authenticated;
grant all on public.ngo_profiles to service_role;
alter table public.ngo_profiles enable row level security;
create policy "ngo public read" on public.ngo_profiles for select to anon, authenticated using (true);
create policy "ngo own update" on public.ngo_profiles for update to authenticated using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));
create or replace function public.guard_ngo_verification() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if new.verification_status is distinct from old.verification_status and not public.has_role(auth.uid(),'admin') then
    new.verification_status := old.verification_status;
  end if;
  new.updated_at := now();
  return new;
end $$;
create trigger trg_guard_ngo before update on public.ngo_profiles for each row execute function public.guard_ngo_verification();

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
declare
  r text := coalesce(new.raw_user_meta_data->>'role','student');
  yr int;
begin
  if r not in ('student','canteen','ngo') then r := 'student'; end if;
  begin yr := nullif(new.raw_user_meta_data->>'academic_year','')::int; exception when others then yr := null; end;
  if yr is not null and (yr < 1 or yr > 6) then yr := null; end if;
  insert into public.profiles(id, display_name, status, branch, academic_year)
  values (new.id, left(coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email,'@',1)),100),
          case when r='canteen' then 'pending' else 'active' end,
          case when r='student' then left(new.raw_user_meta_data->>'branch',50) end,
          case when r='student' then yr end);
  insert into public.user_roles(user_id, role) values (new.id, r::public.app_role);
  if r = 'ngo' then
    insert into public.ngo_profiles(user_id, org_name) values (new.id, left(coalesce(new.raw_user_meta_data->>'org_name', new.raw_user_meta_data->>'display_name','New NGO'),150));
  end if;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create table public.branches (id uuid primary key default gen_random_uuid(), name text unique not null, student_count int not null default 0 check (student_count >= 0));
create table public.lunch_break_schedules (
  id uuid primary key default gen_random_uuid(),
  branch text not null, academic_year int not null check (academic_year between 1 and 6),
  day_of_week int not null check (day_of_week between 0 and 6),
  start_time time not null, end_time time not null check (end_time > start_time),
  created_at timestamptz not null default now()
);
create table public.announcements (
  id uuid primary key default gen_random_uuid(), title text not null, body text not null default '',
  published boolean not null default true, created_by uuid, created_at timestamptz not null default now()
);
create table public.menu_items (
  id uuid primary key default gen_random_uuid(), name text not null, category text not null default 'Meal',
  price numeric(10,2) not null default 0 check (price >= 0), is_available boolean not null default true,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.canteen_seating_status (
  id int primary key default 1 check (id = 1), total_seats int not null default 0 check (total_seats >= 0),
  occupied_seats int not null default 0 check (occupied_seats >= 0), updated_at timestamptz, updated_by uuid
);
insert into public.canteen_seating_status(id) values (1);
insert into public.branches(name) values ('Computer Science'),('Electronics'),('Mechanical'),('Civil'),('Electrical'),('IT');

grant select on public.branches, public.lunch_break_schedules, public.announcements, public.menu_items, public.canteen_seating_status to anon, authenticated;
grant insert, update, delete on public.branches, public.lunch_break_schedules, public.announcements, public.menu_items, public.canteen_seating_status to authenticated;
grant all on public.branches, public.lunch_break_schedules, public.announcements, public.menu_items, public.canteen_seating_status to service_role;
alter table public.branches enable row level security;
alter table public.lunch_break_schedules enable row level security;
alter table public.announcements enable row level security;
alter table public.menu_items enable row level security;
alter table public.canteen_seating_status enable row level security;
create policy "read branches" on public.branches for select using (true);
create policy "admin branches" on public.branches for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "read schedules" on public.lunch_break_schedules for select to authenticated using (true);
create policy "admin schedules" on public.lunch_break_schedules for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "read published ann" on public.announcements for select to authenticated using (published or public.is_staff(auth.uid()));
create policy "staff ann" on public.announcements for all to authenticated using (public.is_staff(auth.uid())) with check (public.is_staff(auth.uid()));
create policy "read menu" on public.menu_items for select using (true);
create policy "staff menu" on public.menu_items for all to authenticated using (public.is_staff(auth.uid())) with check (public.is_staff(auth.uid()));
create policy "read seating" on public.canteen_seating_status for select using (true);
create policy "staff seating" on public.canteen_seating_status for update to authenticated using (public.is_staff(auth.uid()));

create table public.grocery_items (
  id uuid primary key default gen_random_uuid(), name text unique not null,
  unit text not null check (unit in ('kg','g','l','ml','packets','pieces')),
  min_stock numeric not null default 0 check (min_stock >= 0), created_at timestamptz not null default now()
);
create table public.inventory_transactions (
  id uuid primary key default gen_random_uuid(),
  grocery_item_id uuid not null references public.grocery_items(id) on delete cascade,
  txn_type text not null check (txn_type in ('opening','purchase','return_in','consumption','waste','adjustment')),
  quantity numeric not null check (quantity <> 0),
  cost numeric(10,2), supplier text, expiry_date date, note text, batch_id uuid,
  txn_date date not null default current_date, created_by uuid, created_at timestamptz not null default now()
);
create index on public.inventory_transactions(grocery_item_id, txn_date);
create table public.recipe_ingredients (
  id uuid primary key default gen_random_uuid(),
  menu_item_id uuid not null references public.menu_items(id) on delete cascade,
  grocery_item_id uuid not null references public.grocery_items(id) on delete cascade,
  qty_per_portion numeric not null check (qty_per_portion > 0),
  unique(menu_item_id, grocery_item_id)
);
create table public.food_preparation_batches (
  id uuid primary key default gen_random_uuid(),
  menu_item_id uuid not null references public.menu_items(id) on delete cascade,
  prep_date date not null default current_date, lunch_period text,
  prepared_qty int not null check (prepared_qty > 0),
  sold_qty int not null default 0 check (sold_qty >= 0),
  donated_qty int not null default 0 check (donated_qty >= 0),
  discarded_qty int not null default 0 check (discarded_qty >= 0),
  created_by uuid, created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  check (sold_qty + donated_qty + discarded_qty <= prepared_qty)
);
create index on public.food_preparation_batches(prep_date);
create table public.audit_logs (id uuid primary key default gen_random_uuid(), actor uuid, action text not null, entity text, entity_id uuid, details jsonb, created_at timestamptz not null default now());

grant select, insert, update, delete on public.grocery_items, public.inventory_transactions, public.recipe_ingredients, public.food_preparation_batches to authenticated;
grant select, insert on public.audit_logs to authenticated;
grant all on public.grocery_items, public.inventory_transactions, public.recipe_ingredients, public.food_preparation_batches, public.audit_logs to service_role;
grant select on public.food_preparation_batches to anon;
alter table public.grocery_items enable row level security;
alter table public.inventory_transactions enable row level security;
alter table public.recipe_ingredients enable row level security;
alter table public.food_preparation_batches enable row level security;
alter table public.audit_logs enable row level security;
create policy "staff groceries" on public.grocery_items for all to authenticated using (public.is_staff(auth.uid())) with check (public.is_staff(auth.uid()));
create policy "staff txns" on public.inventory_transactions for all to authenticated using (public.is_staff(auth.uid())) with check (public.is_staff(auth.uid()));
create policy "staff recipes" on public.recipe_ingredients for all to authenticated using (public.is_staff(auth.uid())) with check (public.is_staff(auth.uid()));
create policy "staff batches" on public.food_preparation_batches for all to authenticated using (public.is_staff(auth.uid())) with check (public.is_staff(auth.uid()));
create policy "public impact read" on public.food_preparation_batches for select to anon, authenticated using (true);
create policy "admin audit read" on public.audit_logs for select to authenticated using (public.has_role(auth.uid(),'admin'));
create policy "staff audit insert" on public.audit_logs for insert to authenticated with check (public.is_staff(auth.uid()) and actor = auth.uid());

create view public.ingredient_stock with (security_invoker = true) as
select g.id, g.name, g.unit, g.min_stock,
  coalesce(sum(case when t.txn_type in ('opening','purchase','return_in') then t.quantity
                    when t.txn_type in ('consumption','waste') then -t.quantity
                    else t.quantity end),0) as current_stock,
  coalesce(sum(case when t.txn_type='consumption' and t.txn_date >= current_date - 14 then t.quantity end),0)/14.0 as avg_daily_use,
  min(t.expiry_date) filter (where t.txn_type='purchase' and t.expiry_date >= current_date) as next_expiry
from public.grocery_items g left join public.inventory_transactions t on t.grocery_item_id = g.id
group by g.id;
grant select on public.ingredient_stock to authenticated;

create or replace function public.record_preparation(_menu_item uuid, _qty int, _period text)
returns uuid language plpgsql security invoker set search_path = public as $$
declare bid uuid;
begin
  if not public.is_staff(auth.uid()) then raise exception 'not authorized'; end if;
  insert into public.food_preparation_batches(menu_item_id, prepared_qty, lunch_period, created_by)
  values (_menu_item, _qty, _period, auth.uid()) returning id into bid;
  insert into public.inventory_transactions(grocery_item_id, txn_type, quantity, batch_id, note, created_by)
  select grocery_item_id, 'consumption', qty_per_portion * _qty, bid, 'Auto: recipe deduction', auth.uid()
  from public.recipe_ingredients where menu_item_id = _menu_item;
  insert into public.audit_logs(actor, action, entity, entity_id, details) values (auth.uid(),'record_preparation','food_preparation_batches',bid, jsonb_build_object('qty',_qty));
  return bid;
end $$;

create table public.surplus_food_listings (
  id uuid primary key default gen_random_uuid(), batch_id uuid references public.food_preparation_batches(id) on delete set null,
  description text not null, quantity int not null check (quantity > 0), unit text not null default 'portions',
  prepared_at timestamptz not null default now(), available_until timestamptz not null,
  status text not null default 'open' check (status in ('open','allocated','picked_up','expired','cancelled')),
  created_by uuid, created_at timestamptz not null default now()
);
create table public.donation_requests (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.surplus_food_listings(id) on delete cascade,
  ngo_id uuid not null references public.ngo_profiles(user_id) on delete cascade,
  note text default '', status text not null default 'requested' check (status in ('requested','approved','rejected','picked_up')),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique(listing_id, ngo_id)
);
create table public.ngo_posts (
  id uuid primary key default gen_random_uuid(), ngo_id uuid not null references public.ngo_profiles(user_id) on delete cascade,
  title text not null, body text not null default '', image_url text, location text, beneficiaries int check (beneficiaries >= 0),
  activity_date date, status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);
create table public.notifications (
  id uuid primary key default gen_random_uuid(), user_id uuid not null, title text not null, body text default '',
  read boolean not null default false, created_at timestamptz not null default now()
);
create index on public.notifications(user_id, created_at desc);
grant select, insert, update, delete on public.surplus_food_listings, public.donation_requests, public.ngo_posts, public.notifications to authenticated;
grant select on public.ngo_posts to anon;
grant all on public.surplus_food_listings, public.donation_requests, public.ngo_posts, public.notifications to service_role;
alter table public.surplus_food_listings enable row level security;
alter table public.donation_requests enable row level security;
alter table public.ngo_posts enable row level security;
alter table public.notifications enable row level security;

create or replace function public.is_verified_ngo(_uid uuid) returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.ngo_profiles where user_id=_uid and verification_status='verified')
$$;
create policy "staff listings" on public.surplus_food_listings for all to authenticated using (public.is_staff(auth.uid())) with check (public.is_staff(auth.uid()));
create policy "verified ngo read listings" on public.surplus_food_listings for select to authenticated using (public.is_verified_ngo(auth.uid()));
create policy "ngo own requests" on public.donation_requests for select to authenticated using (ngo_id = auth.uid() or public.is_staff(auth.uid()));
create policy "ngo create request" on public.donation_requests for insert to authenticated with check (ngo_id = auth.uid() and status='requested' and public.is_verified_ngo(auth.uid()));
create policy "staff update requests" on public.donation_requests for update to authenticated using (public.is_staff(auth.uid()));
create policy "public approved posts" on public.ngo_posts for select to anon, authenticated using (status='approved' or ngo_id = auth.uid() or public.has_role(auth.uid(),'admin'));
create policy "ngo create post" on public.ngo_posts for insert to authenticated with check (ngo_id = auth.uid() and status='pending');
create policy "ngo delete own post" on public.ngo_posts for delete to authenticated using (ngo_id = auth.uid() or public.has_role(auth.uid(),'admin'));
create policy "admin moderate post" on public.ngo_posts for update to authenticated using (public.has_role(auth.uid(),'admin'));
create policy "own notifications" on public.notifications for select to authenticated using (user_id = auth.uid());
create policy "own notifications update" on public.notifications for update to authenticated using (user_id = auth.uid());
create policy "own notifications delete" on public.notifications for delete to authenticated using (user_id = auth.uid());

create or replace function public.notify_role(_role public.app_role, _title text, _body text) returns void language sql security definer set search_path=public as $$
  insert into public.notifications(user_id,title,body) select user_id,_title,_body from public.user_roles where role=_role
$$;
revoke execute on function public.notify_role from public, anon, authenticated;
create or replace function public.on_announcement() returns trigger language plpgsql security definer set search_path=public as $$
begin if new.published then perform public.notify_role('student', 'Announcement: '||new.title, left(new.body,200)); end if; return new; end $$;
create trigger trg_ann after insert on public.announcements for each row execute function public.on_announcement();
create or replace function public.on_listing() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.notifications(user_id,title,body) select user_id,'New surplus food available', new.quantity||' '||new.unit||': '||new.description from public.ngo_profiles where verification_status='verified';
  return new; end $$;
create trigger trg_listing after insert on public.surplus_food_listings for each row execute function public.on_listing();
create or replace function public.on_request_update() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if new.status is distinct from old.status then
    insert into public.notifications(user_id,title,body) values (new.ngo_id,'Donation request '||new.status,'Your request status changed to '||new.status);
    if new.status='approved' then update public.surplus_food_listings set status='allocated' where id=new.listing_id; end if;
    if new.status='picked_up' then update public.surplus_food_listings set status='picked_up' where id=new.listing_id; end if;
  end if;
  new.updated_at := now(); return new; end $$;
create trigger trg_req before update on public.donation_requests for each row execute function public.on_request_update();
create or replace function public.on_seating() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if new.total_seats > 0 and new.occupied_seats::numeric/new.total_seats >= 0.9 and (old.total_seats = 0 or old.occupied_seats::numeric/old.total_seats < 0.9) then
    perform public.notify_role('student','Canteen almost full','Seating is limited right now. Consider waiting a few minutes.');
  elsif new.total_seats > 0 and new.occupied_seats::numeric/new.total_seats < 0.6 and old.total_seats > 0 and old.occupied_seats::numeric/old.total_seats >= 0.9 then
    perform public.notify_role('student','Seats available','Canteen seating has opened up.');
  end if;
  return new; end $$;
create trigger trg_seat after update on public.canteen_seating_status for each row execute function public.on_seating();

alter publication supabase_realtime add table public.canteen_seating_status;
alter publication supabase_realtime add table public.notifications;
alter publication supabase_realtime add table public.menu_items;